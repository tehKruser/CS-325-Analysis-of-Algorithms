Project 1
Group 7
Names: Justin Kruse, Nicholas Koller, (Phillip Scott Cooper) <-- Dropped and completed no work

Description:
Our program divided each algorithm implementation into it's own function and had a driver program run them.
They run in the following order: Enumeration, Better enumeration, Divide and Conquer, and Linear-time

Instructions for running program:
1. Extract files to desired directory.
2. Using the command line shell in the same directory,  enter the following command: 
python3 project1.py