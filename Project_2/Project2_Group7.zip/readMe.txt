Instructions:

3 options for running:

1. Run solutions on file only - arguments: filename
	Command Line Entry:
	python3 program2.py {yourfilename}.txt
	
	Result:
	Runs solutions on the specified file


2. Run solutions on file AND execute experimental runs - arguments: filename exp
	Command Line Entry:
	python3 program2.py {yourfilename}.txt exp
	
	Result:
	Runs solutions on the specified file
	Runs all experimental runs
	
	****Note: This option takes approximately 9 minutes to execute
	
	
3. Default - arguments: none
	Command Line Entry:
	python3 program2.py
	
	Result:
	Runs solutions on coins.txt
	
	
